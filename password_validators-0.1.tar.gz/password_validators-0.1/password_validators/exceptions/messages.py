exceptions = {
    "name": "exceptions message",
    "preparing_date": "07.04.2022",
    "version": "0.1",
    "ValidationError": {
        "has_number_validator": "Password must contain at least one number.",
        "has_special_character": "Password must contain at least one special characters.",
        "has_upper_characters": "Password must contain one or more upper letter.",
        "has_lower_characters": "Password must contain or more lower letter.",
        "long_enough": "Password is too short.",
        "leaked_password": "This password are leaked. Chose another one.",
    },
}
