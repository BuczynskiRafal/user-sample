"""Collection of validation error exception."""
# import yaml
#
# with open("messages.yaml", "r") as file:
#     exceptions = yaml.safe_load(file)


class ValidationError(Exception):
    """Validation error exception"""
